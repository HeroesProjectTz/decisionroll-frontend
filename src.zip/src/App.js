import * as React from 'react'
import {
  BrowserRouter as Router,
  useRoutes,
} from "react-router-dom";
import { Box, ChakraProvider } from '@chakra-ui/react'
import SideBar from './components/sidebar/sidebar'
import {Decision,Decisions,Vote,Users,Home,LoginPage} from './components/index'

const AppWrapper = () => {
  let routes = useRoutes([
    { path: "/login", element: <LoginPage /> },
    {
      path: "",
      element:
      
      <Box display='grid' gridTemplateColumns='17rem auto'>
        <SideBar />
        <Home />
        </Box>
    },
    {
      path: "dashboard/users",
      element:
      
      <Box display='grid' gridTemplateColumns='17rem auto'    >
        <SideBar />
        <Users />
        </Box>
    },
    {
      path: "dashboard/decisions",
      element:
      
      <Box display='grid' gridTemplateColumns='17rem auto'    >
        <SideBar />
        <Decisions />
        </Box>
    },
    {
      path: "dashboard/decision/:id",
      element:
      
      <Box display='grid' gridTemplateColumns='17rem auto'    >
        <SideBar />
        <Decision />
        </Box>
    },
    {
      path: "dashboard/vote/:id",
      element:
      
      <Box display='grid' gridTemplateColumns='17rem auto'    >
        <SideBar />
        <Vote />
        </Box>
    },
    // ...
  ]);
  return routes;
};

function App() {
  return (
    <ChakraProvider>
      <Router>
        <AppWrapper />
      </Router>
    </ChakraProvider>
  );
}

export default App;
