import React from 'react'
import { Box, Text,Flex,Center,Input,Button,Avatar} from '@chakra-ui/react'
const LoginPage = () => {
  return (

    <Box>  
       <Flex direction='column' justify='center' justifyContent='center' align='center' mt='10%' >
        <Text fontWeight='bold' fontSize={20}>Sign In To Decision Roll</Text>
        <Text mt={3} fontWeight='600' fontSize={14}>Enter your details below</Text>
        <Input placeholder='username' height='1.3375em'  borderRadius='12' alignContent='center' width='30%' mt={3} backgroundColor='white' borderColor='#4c688f' variant='filled' pt={8} pb={8} />
        <Button colorScheme='teal' variant='solid' mt={10} width="30%" height='6vh'>
       Login
     </Button>
     <Text mt={3} fontWeight='600' fontSize={14}>Or</Text>
     <Button colorScheme='yellow' variant='solid' mt={10} width="30%" height='6vh'>
       Sign In With Google
     </Button>
      </Flex>
      </Box>
  )
}

export default LoginPage