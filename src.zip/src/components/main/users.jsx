import React from 'react'
import {
    Table,
    Thead,
    Tbody,
    Tfoot,
    Tr,
    Th,
    Td,
    TableCaption,
    TableContainer,
    Box,
    Text
  } from '@chakra-ui/react'
import AvatarDropDown from './avatardropdown'

const Users = () => {
  return (
    <Box mt={14} mr={4}> 
        <AvatarDropDown/>
    <Box backgroundColor="#f3f3f3"  rounded='lg' pt={10} pl={10} pr={10} mr={4} ml={4} shadow='sm' mt={20}>
    <Text color='black' fontWeight='bold' fontSize={20}  >Users</Text>
    <Box mt={10}>

    <TableContainer>
  <Table variant='simple' align='left' pl={0} >
    <Thead  >
      <Tr>
        <Th fontWeight='bold' fontSize={15} >Username</Th>
        <Th fontWeight='bold' fontSize={15}>Email</Th>
        <Th fontWeight='bold' fontSize={15}>Last Sign In</Th>
        <Th fontWeight='bold' fontSize={15}>Created at</Th>
      </Tr>
    </Thead>
    <Tbody>
      <Tr>
        <Td>Luqman</Td>
        <Td>luqmantuke@gmail.com</Td>
        <Td>29-09-2022 1021</Td>
        <Td>10-08-2022 0933</Td>
      </Tr>
    </Tbody>
  </Table>
</TableContainer>
    
    </Box>    

    </Box>
    </Box>
  )
  
}

export default Users